DRUBY_URI = 'druby://localhost:8787'
